import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import incometaxcalculator.data.management.LoadTaxpayerFactory;
import incometaxcalculator.data.management.SingleTaxpayer;
import incometaxcalculator.exceptions.WrongFileEndingException;
import incometaxcalculator.exceptions.WrongFileFormatException;
import incometaxcalculator.exceptions.WrongReceiptDateException;
import incometaxcalculator.exceptions.WrongReceiptKindException;
import incometaxcalculator.exceptions.WrongTaxpayerStatusException;

class LoadTaxpayerFactoryTest {

  @Test
  void loadTaxpayerTest() throws 
  NumberFormatException, IOException, WrongFileFormatException, WrongFileEndingException, WrongTaxpayerStatusException, WrongReceiptKindException, WrongReceiptDateException {
    String fileName="123456789_INFO.txt";
    LoadTaxpayerFactory obj=new LoadTaxpayerFactory();
    obj.loadTaxpayer(fileName);
    //Assertions.assertTrue(a instanceof SingleTaxpayer);
  
  }

}
