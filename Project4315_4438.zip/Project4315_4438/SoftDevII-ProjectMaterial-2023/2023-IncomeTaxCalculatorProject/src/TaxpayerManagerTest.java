import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.util.HashMap;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import incometaxcalculator.data.management.Taxpayer;
import incometaxcalculator.data.management.TaxpayerManager;
import incometaxcalculator.exceptions.ReceiptAlreadyExistsException;
import incometaxcalculator.exceptions.WrongReceiptDateException;
import incometaxcalculator.exceptions.WrongReceiptKindException;
import incometaxcalculator.exceptions.WrongTaxpayerStatusException;

class TaxpayerManagerTest {
  
  TaxpayerManager t=new TaxpayerManager();
  String fullname="Kostas Koklas";
  int taxRegistrationNumber=123456789;
  String status="Single";
  float income=20000;
  int receiptId=2;
  String issueDate="12/12/2012";
  float amount=4000;
  String kind="HEALTH";
  String companyName="ZARA";
  String country="Spain";
  String city="Barcelona";
  String street="Center";
  int number=9;
 
  
  @Test
  void containsTaxpayerTest() throws WrongTaxpayerStatusException {
    t.createTaxpayer(fullname,taxRegistrationNumber,status,income);
    Assertions.assertTrue(t.containsTaxpayer());
  }
  
  @Test
  void getTaxpayerNameTest() throws WrongTaxpayerStatusException {
    Assertions.assertNotNull(t.getTaxpayerName(taxRegistrationNumber));
    Assertions.assertEquals("Kostas Koklas",t.getTaxpayerName(taxRegistrationNumber));
  }
  
  @Test
  void getTaxpayerStatus() throws WrongTaxpayerStatusException {
    String s=t.getTaxpayerStatus(taxRegistrationNumber);
    Assertions.assertEquals("Single",s);
  }
  void gettersTest() {
    Assertions.assertEquals(t.getTaxpayerIncome(taxRegistrationNumber),20000);
    
  }
 
  @Test
  void updateFiles() throws IOException{
    t.updateFiles(taxRegistrationNumber);
    //Assertions.assertNotNull(t.updateFiles(taxRegistrationNumber) );
  }
}
