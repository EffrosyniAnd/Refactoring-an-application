import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import incometaxcalculator.data.management.Company;
import incometaxcalculator.data.management.Receipt;
import incometaxcalculator.data.management.SingleTaxpayer;
import incometaxcalculator.data.management.Taxpayer;
import incometaxcalculator.data.management.TaxpayerManager;
import incometaxcalculator.exceptions.WrongReceiptDateException;
import incometaxcalculator.exceptions.WrongReceiptKindException;

class TaxpayerTest {
 
  
    //method Add Receipt test
    @Test
    void testaddReceipt()throws Exception{
     
     try{
        int receiptId=1;
        String issueDate="25/02/2014";
        float amount=2000;
        String kind="Basic";
        String companyName="HandMade Clothes";
        String country="Greece";
        String city="Ioannina";
        String street="Kaloudi";
        int number=10;
        short k=1;
        
        HashMap<Integer, Receipt> receiptHashMap = new HashMap<Integer, Receipt>(0);
        Company company=new Company(companyName,country,city,street,number);
        Receipt resObj=new Receipt(receiptId,issueDate,amount,kind,company);
        
        SingleTaxpayer s=new SingleTaxpayer("MARIA LYTRA",1,20000);
        s.addReceipt(resObj);
       
        Assertions.assertEquals(2000,s.getAmountOfReceiptKind(k));
        Assertions.assertEquals(1,s.getTotalReceiptsGathered()); 
        
     }
     catch(WrongReceiptKindException e) {
       System.out.println(e);
       
     }
   }
  //Ypologizoyme to basicTax gia to singleTaxpayer
  @Test
  void testgetBasicTax() {
    SingleTaxpayer s=new SingleTaxpayer("MARIA LYTRA",1,20000);
    Assertions.assertEquals(1070,s.getBasicTax());
    
  }
 
  //Here we test the GetVariationTaxONReceipt method
  @Test
  void getVariationTaxOnReceipts() {
    SingleTaxpayer s=new SingleTaxpayer("MARIA LYTRA",1,20000);
    double a=s.getVariationTaxOnReceipts();
    Assertions.assertEquals(85.60000000000001,a);
  }
  
  
  @Test
  void testRemoveReceipt()throws Exception{
   
   try{
      int receiptId=1;
      String issueDate="25/02/2020";
      float amount=2000;
      String kind="Health";
      String companyName="HandMade Clothes";
      String country="Greece";
      String city="Ioannina";
      String street="Kaloudi";
      int number=10;
      short k=3;
      

      Company company=new Company(companyName,country,city,street,number);
      Receipt resObj=new Receipt(receiptId,issueDate,amount,kind,company);
     
      
      SingleTaxpayer s=new SingleTaxpayer("MARIA LYTRA",1,20000);
      s.addReceipt(resObj);
      s.removeReceipt(receiptId);
     
      Assertions.assertEquals(0,s.getAmountOfReceiptKind(k));
      Assertions.assertEquals(0,s.getTotalReceiptsGathered());
      
      
      
   }
   catch(Exception e) {
     System.out.print("False");
   }
  }
 
 
  
 
  
}
